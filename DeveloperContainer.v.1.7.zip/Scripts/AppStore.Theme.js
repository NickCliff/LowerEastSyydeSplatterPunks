﻿
// AppStore.Theme.js

try {
	window.console.log("DEPRECATED: AppStore.Theme.js is now included in AppStore.Common.js.");
}
catch (ex) {
}
