﻿function clickMe() {
	alert('Hello');
}